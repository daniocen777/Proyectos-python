''' Módulo con funciones que saludan '''
def despedida():
    print('Holas, te despedimos desde la función de módulo de despedidas')

class Despedida:
    def __init__(self):
        print('Holas, te estamos despidiendo desde el init de la clase Despedida')