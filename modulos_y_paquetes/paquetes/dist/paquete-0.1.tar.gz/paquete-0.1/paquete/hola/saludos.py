''' Módulo con funciones que saludan '''
def saludar():
    print('Holas, te saludamos desde saludos')

class Saludo:
    def __init__(self):
        print('Holas, te estamos saludando desde el init de la clase saludo')